# developing_countries_stock_market
Analyzing stock markets in different development groups
